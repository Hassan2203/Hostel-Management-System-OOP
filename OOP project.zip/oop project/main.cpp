#include<iostream>
#include<fstream>
#include<string>
#include <iomanip>
using namespace std;
char ch= 178;

int sleep(int n)
{
    for(int i=0; i<(n*5000) ; i++)
    {

    }
}
class Room
{
protected:
    int room_no;
    string type; // "student", "faculty", "guest"
    bool available;
    string occupant_id;
    float total_dues;
public:
    Room(int r = 0, string t = "student", bool a = true, string occ_id = "", float dues=0) :
        room_no(r), type(t), available(a), occupant_id(occ_id), total_dues(dues) {}
    int getRoomNo() const
    {
        return room_no;
    }
    bool isAvailable() const
    {
        return available;
    }
    string getOccupantId() const
    {
        return occupant_id;
    }

    // Setters
    void allocateRoom(string occupant_id)
    {
        available = false;
        this->occupant_id = occupant_id;
    }

    void freeRoom()
    {
        available = true;
        occupant_id = "";
    }
    float save_dues(float d)
    {
        total_dues=d;
    }
    float get_dues()
    {
        return total_dues;
    }

    void displayRoom(string type) const
    {
        cout << "Room No: " << room_no << " | Type: " << type << " | Available: " << (available ? "Yes" : "No") << endl;
    }
};

class Person
{
protected:
    string name;
    string id;
    string contact;
public:
    Person(string n, string i, string c) : name(""), id(""), contact("") {}
    virtual string type() const = 0; // Pure virtual function
};


class student_hostel : public Person,public Room
{
private:
    string roll_no;
    string department;
    string year;
    static const int student_capacity =200 ; // Maximum 200 rooms
    Room rooms[student_capacity]; // Array of rooms
public:
    student_hostel(string n, string i, string c, string r, string d, string y) :
        Person(n, i, c), roll_no(r), department(d), year(y)
    {

        // Initialize rooms
        for (int i = 0; i < student_capacity; ++i)
        {
            rooms[i] = Room(i + 1); // Initialize each room with a room number (1 to 200)
        }
    }

    // Save student data to file
    void save_student_hostel(string name, string id, string contact, string roll_no, string department, string year, int room_no,float total_dues)
    {

        ofstream stdt("save_student_hostel.csv", ios::app);
        if (!stdt.is_open())
        {
            cout << "ERROR: Unable to open file to add the student.\n";
        }
        else
        {

            stdt << name << "," << id << "," << contact << "," << roll_no << "," << department << "," << year << "," << room_no <<","<<total_dues << endl;
            stdt.close();
            cout << "Student added successfully.\n";
        }
    }
    void load_student_hostel()
    {
        ifstream load_stdt("save_student_hostel.csv");
        if (!load_stdt.is_open())
        {
            cout << "ERROR: Unable to open file to load the student.\n";
        }
        else
        {
            cout<<" \t\t\t\t\t\t\t\t  Load students data "<<endl;
            for(int i=0; i<167; i++)
            cout<<ch;
            cout<<endl;
            float total_dues;
            string header;
            getline(load_stdt,header);
            cout << ch << " " << setw(20) << left << "Name"
         << ch << " " << setw(20) << left << "ID"
         << ch << " " << setw(15) << left << "Contact"
         << ch << " " << setw(15) << left << "Roll No"
         << ch << " " << setw(20) << left << "Department"
         << ch << " " << setw(20) << left << "Year"
         << ch << " " << setw(15) << left << "Room No"
         << ch << " " << setw(15) << left << "Total dues" << ch << endl;
            for(int i=0; i<167; i++)
            cout<<ch;
            cout<<endl;
            while (getline(load_stdt, name, ','))
            {
                if (name.empty()) break;
                getline(load_stdt, id, ',');
                getline(load_stdt, contact, ',');
                getline(load_stdt, roll_no, ',');
                getline(load_stdt, department, ',');
                getline(load_stdt, year, ',');
                load_stdt >> room_no;
                load_stdt.ignore();
                load_stdt >> total_dues;
                load_stdt.ignore();

                cout << ch << " " << setw(20) << left << name
         << ch << " " << setw(20) << left << id
         << ch << " " << setw(15) << left << contact
         << ch << " " << setw(15) << left << roll_no
         << ch << " " << setw(20) << left << department
         << ch << " " << setw(20) << left << year
         << ch << " " << setw(15) << left << room_no
         << ch << " " << setw(15) << left << total_dues << ch << endl;
                for (int i = 0; i < student_capacity; i++)
                {
                    if (rooms[i].getRoomNo() == room_no)
                    {
                        rooms[i].allocateRoom(id);
                        rooms[i].save_dues(total_dues);
                    }
                }
            }
            for(int i=0; i<167; i++)
            cout<<ch;
            cout<<endl;
            load_stdt.close();
            cout << "Student data loaded successfully.\n";
        }
    }

    void update_data(string student_id, int new_room_no, bool leave_hostel)
{
    ifstream infile("save_student_hostel.csv");
    ofstream temp_file("temp.csv");

    if (!infile.is_open() || !temp_file.is_open())
    {
        cout << "ERROR: Unable to open file to update the student data." << endl;
        return;
    }

    string header;
    string line; // For reading lines
    bool record_deleted = false;

    // Read the header line and write it to the temp file
    if (getline(infile, header))
    {
        temp_file << header << endl;
    }

    // Process each record line by line
    while (getline(infile, line))
    {
        stringstream ss(line); // Use a stringstream to parse the line
        string name, id, contact, roll_no, department, year;
        int room_no;
        float total_dues;

        // Read values from the stringstream
        getline(ss, name, ',');
        getline(ss, id, ',');
        getline(ss, contact, ',');
        getline(ss, roll_no, ',');
        getline(ss, department, ',');
        getline(ss, year, ',');
        ss >> room_no;
        ss.ignore();
        ss >> total_dues;

        // Check if this is the record to be updated or deleted
        if (id == student_id)
        {
            if (leave_hostel)
            {
                record_deleted = true;
                continue; // Skip writing this record
            }
            room_no = new_room_no; // Update the room number
        }

        // Write data back to the temp file
        temp_file << name << "," << id << "," << contact << "," << roll_no << ","
                  << department << "," << year << "," << room_no << "," << total_dues << endl;
    }

    infile.close();
    temp_file.close();

    // Replace the old file with the updated file
    if (remove("save_student_hostel.csv") != 0)
    {
        cout << "ERROR: Unable to delete the old file." << endl;
        return;
    }
    if (rename("temp.csv", "save_student_hostel.csv") != 0)
    {
        cout << "ERROR: Unable to rename the temporary file." << endl;
        return;
    }

    cout << "Student data updated successfully!" << endl;
}

    void addStudent()
    {
        cout<<" \t\t\t\t\t\t\t\t Add student "<<endl;
        for(int i=0; i<167; i++)
            cout<<ch;
        cout<<endl;
        string name, id, contact, roll_no, department, year;
        int room_no;

        cout << "\n Enter student details:" << endl;
        cout << "Name : ";
        cin.ignore();
        getline(cin, name);
        cout << "ID : ";
        cin >> id;
        cout << "Contact : ";
        cin >> contact;
        cout << "Roll No : ";
        cin >> roll_no;
        cout << "Department : ";
        cin >> department;
        cout << "Year : ";
        cin >> year;
        while(true)
        {
            cout<<"Room No (1-200) : ";
            cin>>room_no;
            if(room_no>200 || room_no<=0)
            {
                cout<<"You have entered an invalid room number. Try again. "<<endl;
            }
            else
            {
                break;
            }
        }
        cout<<"Do you want to take the inverter facility? (yes/no) : ";
        string option;
        cin>>option;
        float bill=12000;
        float total;
        if(option=="no")
        {
            total=bill;
            cout<<"Total charges for hostel : "<< total <<endl;
        }
        else if(option=="yes")
        {
            total=bill+5000;
            cout<<"Total charges for hostel : "<< total <<endl;
        }
        else
        {
            cout<<"Sorry entered a wrong command. "<<endl;
        }
        // Search for an available room
        bool room_allocated = false;
        for (int i = 0; i < student_capacity; ++i)
        {
            if(rooms[i].getRoomNo()==room_no)
            {
                if (rooms[i].isAvailable()==true)
                {
                    rooms[i].allocateRoom(id); // Assign the room to the student
                    room_allocated = true;
                    break;
                }
            }
        }

        if (room_allocated==true)
        {
            cout << "Room " << room_no << " allocated to " << name << endl;
            string choice;
            cout<<"Do you want to pay the dues right now?(yes/no) :";
            cin>>choice;
            if (choice=="yes")
            {
                cout<<"Thank you the money "<< total <<" has been recieved."<<endl;
                total=0;
                save_student_hostel(name, id, contact, roll_no, department, year, room_no, total);
            }
            else if(choice=="no")
            {
                cout<<"No problem you can send the money later."<<endl;
                cout<<"Total : "<< total <<" has been added to your account as dues."<<endl;
                save_student_hostel(name, id, contact, roll_no, department, year, room_no, total);
            }
        }
        else if(room_allocated==false)
        {
            cout << "Error :- No rooms available for allocation!" << endl;
        }
    }
    int change_room()
    {
        cout<<" \t\t\t\t\t\t\t\t change room "<<endl;
        for(int i=0; i<167; i++)
            cout<<ch;
        cout<<endl;

        string student_id;
        cout << "Enter your student ID: ";
        cin >> student_id;
        string choice;
        cout<<"Do you want to change the room?(yes/no) ";
        cin>>choice;
        if(choice=="no")
        {
            cout<<"------------Stay Happy----------"<<endl;
        }
        else if(choice=="yes")
        {
            int option;
            cout<<"what is the reason for changing the room? "<<endl;
            cout<<"1- Health problem "<<endl;
            cout<<"2- Room wiring problem "<<endl;
            cout<<"3- Air conditioning problems "<<endl;
            cin>>option;
            if(option==2)
            {
                cout<<"Sorry but we will fix this problem in 1-2 days."<<endl;
                cout<<"Don't take tension. Thank you. "<<endl;
            }

            else if(option==3)
            {
                cout<<"Sorry but we will fix this problem in a week."<<endl;
                cout<<"Don't take tension. stay blessed. Thank you. "<<endl;
            }
            else if(option==1)
            {
                cout<<"wait a moment. I am working on it."<<endl;
                sleep(200000);
                bool room_found= false;
                int old_room_no = -1;
                // Find the student and free their current room
                int index;
                if(!room_found == true )
                {
                    for (int i = 0; i < student_capacity; i++)
                    {
                        if(rooms[i].getOccupantId()==student_id)
                        {
                            index=i;
                            old_room_no = rooms[i].getRoomNo();
                            rooms[i].freeRoom(); // Free up the current room
                            room_found = true;
                            cout << "Room " << old_room_no << " freed. You can now change to another room." << endl;
                            break;
                        }
                    }
                }
                if (room_found==false)
                {
                    cout << "Student not found or room already freed." << endl;
                    return 1;
                }
                bool new_room_allocated;
                bool leave_hostel=false;
                for (int i = 0; i < student_capacity; i++)
                {
                    if(!(i==index))
                    {
                        if (rooms[i].isAvailable())
                        {
                            rooms[i].allocateRoom(student_id);
                            rooms[i].get_dues();
                            int new_room_no = rooms[i].getRoomNo();
                            cout << "Room " << new_room_no << " allocated to student " << student_id << endl;
                            new_room_allocated = true;
                            leave_hostel=false;
                            update_data(student_id, new_room_no,false);
                            break;
                        }
                    }
                }
                if (new_room_allocated==false)
                {
                    cout << "No rooms available for the student!" << endl;
                }
            }
        }
    }

    int migration()
    {
        cout<<" \t\t\t\t\t\t\t\t Migration "<<endl;
        for(int i=0; i<167; i++)
            cout<<ch;
        cout<<endl;
        string student_id;
        cout << "Enter your student ID: ";
        cin >> student_id;
        bool room_found= false;
        int old_room_no = -1;
        bool leave_hostel=false;
        // Find the student and free their current room
        if(!room_found == true )
        {
            for (int i = 0; i < student_capacity; i++)
            {
                if(rooms[i].getOccupantId()==student_id)
                {
                    old_room_no = rooms[i].getRoomNo();
                    if(rooms[i].get_dues()==0)
                    {
                        cout<<"You have pending "<<rooms[i].get_dues()<< " dues."<<endl;
                        rooms[i].freeRoom(); // Free up the current room
                        room_found = true;
                        cout << "Room " << old_room_no << " freed successfully. "<<endl;
                        cout<<"Migration successfull."<<endl;
                        leave_hostel=true;
                        update_data(student_id, rooms[i].getRoomNo(),true);
                    }
                    else
                    {
                        string choice;
                        cout<<"You have pending "<<rooms[i].get_dues()<< " dues."<<endl;
                        cout<<"You cannot migrate right now without clearing the dues."<<endl;
                        cout<<"Do you want to pay the dues right now?(yes/no) : ";
                        cin>>choice;
                        if(choice=="yes")
                        {
                            rooms[i].get_dues()==0;
                            cout<<"Thanks for paying your dues. Now you can Migrate. "<<endl;
                            rooms[i].freeRoom(); // Free up the current room
                            room_found = true;
                            cout << "Room " << old_room_no << " freed successfully. "<<endl;
                            leave_hostel=true;

                            update_data(student_id, rooms[i].getRoomNo(),true);
                        }
                        else if (choice=="no")
                        {
                            cout<<"You cannot migrate right now without clearing the dues. Thank You."<<endl;
                        }
                    }
                    break;
                }
            }
        }
        if (room_found==false)
        {
            cout << "Student not found or room already freed." << endl;
            return 1;
        }
    }

    string type() const override
    {
        return "student";
    }
    void displayAvailableRooms()
    {
        cout<<" \t\t\t\t\t\t\t\t Rooms details "<<endl;
        for(int i=0; i<167; i++)
            cout<<ch;
        cout<<endl;
        bool any_room_available = false;
        for (int i = 0; i < student_capacity; ++i)
        {
            if (rooms[i].isAvailable())
            {
                rooms[i].displayRoom( type() );
                any_room_available = true;
            }
        }

        if (any_room_available==false)
        {
            cout << "No rooms are available." << endl;
        }
    }
};

class facultystaff_hostel : public Person,public Room
{
private:
    string department;
    string possition;
    static const int capacity = 20;
    Room room[capacity]; // Array of rooms
public:
    facultystaff_hostel(string n, string i, string c, string d, string p) :
        Person(n, i, c), department(""), possition("")
    {
        // Initialize rooms
        for (int i = 0; i < capacity; i++)
        {
            room[i] = Room(i + 1); // Initialize each room with a room number (1 to 200)
        }
    }

    void save_faculty_hostel(string name, string id, string contact,string department, string possition, int room_no,float total_dues)
    {
        ofstream fclty("save_faculty_and_staff_hostel.csv", ios::app);
        if (!fclty.is_open())
        {
            cout << "ERROR: Unable to open file to add the faculty or staff member.\n";
        }
        else
        {
            fclty << name << "," << id << "," << contact << "," << department << "," << possition << "," << room_no <<","<<total_dues << endl;
            fclty.close();
            cout << "faculty/staff member added successfully.\n";
        }
    }

    void load_Faculty_and_staff_hostel()
    {
        ifstream load_fclty("save_faculty_and_staff_hostel.csv");
        if (!load_fclty.is_open())
        {
            cout << "ERROR: Unable to open file to load the faculty or staff.\n";
        }
        else
        {
            float total_dues;
            char ch=178;
            string header;
            cout << " \t\t\t\t\t\t\t\t  Faculty and staff DETAILS \n";
            for(int i=0; i<167; i++)
            cout<<ch;
            cout<<endl;
            getline(load_fclty, header);
            cout << ch << " " << setw(25) << left << "Name"
         << ch << " " << setw(10) << left << "ID"
         << ch << " " << setw(20) << left << "Contact"
         << ch << " " << setw(20) << left << "Department"
         << ch << " " << setw(20) << left << "Position"
         << ch << " " << setw(10) << left << "Room No"
         << ch << " " << setw(10) << left << "Total dues" << ch << endl;
            for(int i=0; i<167; i++)
            cout<<ch;
            cout<<endl;
            while (getline(load_fclty, name, ','))
            {
                if (name.empty()) break;

                getline(load_fclty, id, ',');
                getline(load_fclty, contact, ',');
                getline(load_fclty, department, ',');
                getline(load_fclty, possition, ',');
                load_fclty >> room_no;
                load_fclty.ignore();
                load_fclty >> total_dues;
                load_fclty.ignore();

                cout << ch << " " << setw(25) << left << name
         << ch << " " << setw(10) << left << id
         << ch << " " << setw(20) << left << contact
         << ch << " " << setw(20) << left << department
         << ch << " " << setw(20) << left << possition
         << ch << " " << setw(10) << left << room_no
         << ch << " " << setw(10) << left << total_dues << ch << endl;


                for (int i = 0; i < capacity; i++)
                {
                    if (room[i].getRoomNo() == room_no)
                    {
                        room[i].allocateRoom(id);
                        room[i].save_dues(total_dues);
                    }
                }
            }
            for(int i=0; i<167; i++)
            cout<<ch;
            cout<<endl;
            load_fclty.close();
            cout << "faculty and staff data loaded successfully.\n";
        }
    }

    void update_data(string ID, int new_room_no, bool leave_hostel)
{
    ifstream infile("save_faculty_and_staff_hostel.csv");
    ofstream temp_file("temp.csv");

    if (!infile.is_open() || !temp_file.is_open())
    {
        cout << "ERROR: Unable to open file to update the faculty and staff data." << endl;
        return;
    }

    string header;
    string name, id, contact, department, position;
    int room_no;
    float total_dues;
    bool record_deleted = false;

    // Read the header line and write it to the temp file
    if (getline(infile, header))
    {
        temp_file << header << endl;
    }

    // Process each record line by line
    while (getline(infile, name, ','))
    {
        if (name.empty()) break; // Stop if there's an empty line
        getline(infile, id, ',');
        getline(infile, contact, ',');
        getline(infile, department, ',');
        getline(infile, position, ',');
        infile >> room_no;
        infile.ignore();
        infile >> total_dues;
        infile.ignore();

        // Check if this is the record to be updated or deleted
        if (id == ID)
        {
            if (leave_hostel)
            {
                record_deleted = true;
                continue; // Skip writing this record
            }
            room_no = new_room_no; // Update the room number
        }

        // Write data to the temp file
        temp_file << name << "," << id << "," << contact << "," << department << ","
                  << position << "," << room_no << "," << total_dues << endl;
    }

    infile.close();
    temp_file.close();

    // Replace the old file with the updated file
    if (remove("save_faculty_and_staff_hostel.csv") != 0)
    {
        cout << "ERROR: Unable to delete the old file." << endl;
        return;
    }
    if (rename("temp.csv", "save_faculty_and_staff_hostel.csv") != 0)
    {
        cout << "ERROR: Unable to rename the temporary file." << endl;
        return;
    }

    cout << "Faculty and staff data updated successfully!" << endl;
}

    void add_faculty_or_staff()
    {
        cout << " \t\t\t\t\t\t\t\t  Faculty/Staff details" << endl;
        for(int i=0; i<167; i++)
        cout<<ch;
        cout<<endl;
        cout << "Name : ";
        cin.ignore();
        getline(cin, name);
        cout << "ID : ";
        cin >> id;
        cout << "Contact : ";
        cin >> contact;
        cout << "Department : ";
        cin >> department;
        cout << "Position : ";
        cin >> possition;
        while(true)
        {
            cout<<"Room No (1-20) : ";
            cin>>room_no;
            if(room_no>20 || room_no<=0)
            {
                cout<<"You have entered an invalid room number. Try again. "<<endl;
            }
            else
            {
                break;
            }
        }
        cout<<"Do you want to take the inverter facility? (yes/no) : ";
        string option;
        cin>>option;
        float bill=12000;
        float total;
        if(option=="no")
        {
            total=bill;
            cout<<"Total charges for hostel : "<< total <<endl;

        }
        else if(option=="yes")
        {
            total=bill+5000;
            cout<<"Total charges for hostel : "<< total <<endl;

        }
        else
        {
            cout<<"Sorry entered a wrong command. "<<endl;
        }
        // Search for an available room
        bool room_allocated = false;
        for (int i = 0; i < capacity; i++)
        {
            if(room[i].getRoomNo()==room_no)
            {
                if (room[i].isAvailable()==true)
                {
                    room[i].allocateRoom(id); // Assign the room to the student
                    room_allocated = true;
                    break;
                }
            }
        }

        if (room_allocated==true)
        {
            cout << "Room " << room_no << " allocated to " << name << endl;
            string choice;
            cout<<"Do you want to pay the dues right now?(yes/no) :";
            cin>>choice;
            if (choice=="yes")
            {
                cout<<"Thank you the money "<< total <<" has been recieved."<<endl;
                total=0;
                save_faculty_hostel(name, id, contact, department, possition, room_no, total);
            }
            else if(choice=="no")
            {
                cout<<"No problem you can send the money later."<<endl;
                cout<<"Total : "<< total <<" has been added to your account as dues."<<endl;
                save_faculty_hostel(name, id, contact, department, possition, room_no, total);
            }
        }
        else if(room_allocated==false)
        {
            cout << "Error :- No rooms available for allocation!" << endl;
        }
    }
    int change_room()
    {
        cout<<" \t\t\t\t\t\t\t\t  Room Change "<<endl;
        for(int i=0; i<167; i++)
        cout<<ch;
        cout<<endl;
        string ID;
        cout << "Enter your ID: ";
        cin >> ID;
        string choice;
        cout<<"Do you want to change the room?(yes/no) ";
        cin>>choice;
        if(choice=="no")
        {
            cout<<"------------Stay Happy----------"<<endl;
        }
        else if(choice=="yes")
        {
            int option;
            cout<<"what is the reason for changing the room? "<<endl;
            cout<<"1- Health problem "<<endl;
            cout<<"2- Room wiring problem "<<endl;
            cout<<"3- Air conditioning problems "<<endl;
            cin>>option;
            if(option==2)
            {
                cout<<"Sorry but we will fix this problem in 1-2 days."<<endl;
                cout<<"Don't take tension. Thank you. "<<endl;
            }

            else if(option==3)
            {
                cout<<"Sorry but we will fix this problem in a week."<<endl;
                cout<<"Don't take tension. stay blessed. Thank you. "<<endl;
            }
            else if(option==1)
            {
                cout<<"wait a moment. I am working on it."<<endl;
                sleep(200000);
                bool room_found= false;
                int old_room_no = -1;
                // Find the student and free their current room
                int index;
                if(!room_found == true )
                {
                    for (int i = 0; i < capacity; i++)
                    {
                        if(room[i].getOccupantId()==ID)
                        {
                            index=i;
                            old_room_no = room[i].getRoomNo();
                            room[i].freeRoom(); // Free up the current room
                            room_found = true;
                            cout << "Room " << old_room_no << " freed. You can now change to another room." << endl;
                            break;
                        }
                    }
                }
                if (room_found==false)
                {
                    cout << "Faculty or staff person not found or room already freed." << endl;
                    return 1;
                }
                bool new_room_allocated;
                bool leave_hostel=false;
                for (int i = 0; i < capacity; i++)
                {
                    if(!(i==index))
                    {
                        if (room[i].isAvailable())
                        {
                            room[i].allocateRoom(ID);
                            room[i].get_dues();
                            int new_room_no = room[i].getRoomNo();
                            cout << "Room " << new_room_no << " allocated to  " << ID << endl;
                            new_room_allocated = true;
                            bool leave_hostel=false;
                            update_data(ID, room[i].getRoomNo() , false );
                            break;
                        }
                    }
                }
                if (new_room_allocated==false)
                {
                    cout << "No rooms available for the student!" << endl;
                }
            }
        }
    }

    int leave_hostel()
    {
        cout<<" \t\t\t\t\t\t\t\t  Leave Hostel"<<endl;
        for(int i=0; i<167; i++)
        cout<<ch;
        cout<<endl;
        string id;
        cout << "Enter your ID: ";
        cin >> id;
        bool room_found= false;
        int old_room_no = -1;
        // Find the student and free their current room
        bool leave_hostel = false;
        if(!room_found == true )
        {
            for (int i = 0; i < capacity; i++)
            {
                if(room[i].getOccupantId()==id)
                {
                    old_room_no = room[i].getRoomNo();
                    if(room[i].get_dues()==0)
                    {
                        cout<<"You have pending "<<room[i].get_dues()<< " dues."<<endl;
                        room[i].freeRoom(); // Free up the current room
                        room_found = true;
                        cout << "Room " << old_room_no << " freed successfully. "<<endl;
                        cout<<"Migration successfull."<<endl;
                        update_data(id, room[i].getRoomNo(),leave_hostel = true);
                    }
                    else
                    {

                        string choice;
                        cout<<"You have pending "<<room[i].get_dues()<< " dues."<<endl;
                        cout<<"You cannot leave hostel right now without clearing the dues."<<endl;
                        cout<<"Do you want to pay the dues right now?(yes/no) : ";
                        cin>>choice;
                        if(choice=="yes")
                        {
                            room[i].get_dues()==0;
                            cout<<"Thanks for paying your dues. Now you can Migrate. "<<endl;
                            room[i].freeRoom(); // Free up the current room
                            room_found = true;
                            cout << "Room " << old_room_no << " freed successfully. "<<endl;


                            update_data(id, room[i].getRoomNo(), leave_hostel = true );
                        }
                        else if (choice=="no")
                        {
                            cout<<"You cannot Leave the hostel right now without clearing the dues. Thank You."<<endl;
                        }
                    }
                    break;
                }
            }
        }
        if (room_found==false)
        {
            cout << "FAculty/staff not found or room already freed." << endl;
            return 1;
        }
    }

    string type() const override
    {
        return "Feculty";
    }

    void displayAvailableRooms()
    {
        cout<<" \t\t\t\t\t\t\t\t  Availible Rooms"<<endl;
        for(int i=0; i<167; i++)
        cout<<ch;
        cout<<endl;
        bool any_room_available = false;
        for (int i = 0; i < capacity; i++)
        {
            if (room[i].isAvailable())
            {
                room[i].displayRoom( type() );
                any_room_available = true;
            }
        }

        if (any_room_available==false)
        {
            cout << "No rooms are available." << endl;
        }
    }
};


class guest_rooms : public Person,public Room
{
private:
    string reason_of_stay;
    static const int capacity =3 ; // Maximum 3 rooms
    Room g_room[capacity]; // Array of rooms
public:
    guest_rooms(string n, string i, string c, string r) :
        Person(n, i, c), reason_of_stay(r)
    {

        // Initialize rooms
        for (int i = 0; i < capacity; i++)
        {
            g_room[i] = Room(i + 1); // Initialize each room with a room number (1 to 200)
        }
    }

    void save_guest_room(string name, string id, string contact, string reason_of_stay, int room_no)
    {
        ofstream gst("save_guest_rooms.csv", ios::app);
        if (!gst.is_open())
        {
            cout << "ERROR: Unable to open file to add the guest.\n";
        }
        else
        {
            gst << name << "," << id << "," << contact << ","<< reason_of_stay << "," << room_no << endl;
            gst.close();
            cout << "guest added successfully.\n";
        }
    }
    void load_guest_room()
    {
        ifstream load_gst("save_guest_rooms.csv");
        if (!load_gst.is_open())
        {
            cout << "ERROR: Unable to open file to load the guest rooms.\n";
        }
        else
        {
            char ch=178;
            string header;
            cout << " \t\t\t\t\t\t\t\t  Guest DETAILS \n";
            for(int i=0; i<167; i++)
            cout<<ch;
            cout<<endl;
            getline(load_gst, header);
            cout << ch << " " << setw(15) << left << "Name"
         << ch << " " << setw(10) << left << "ID"
         << ch << " " << setw(15) << left << "Contact"
         << ch << " " << setw(20) << left << "Reason of Stay"
         << ch << " " << setw(10) << left << "Room No" << ch << endl;
            for(int i=0; i<167; i++)
            cout<<ch;
            cout<<endl;
            while (getline(load_gst, name, ','))
            {
                if (name.empty()) break;

                getline(load_gst, id, ',');
                getline(load_gst, contact, ',');
                getline(load_gst, reason_of_stay, ',');
                load_gst >> room_no;
                load_gst.ignore();

                cout << ch << " " << setw(15) << left << name
         << ch << " " << setw(10) << left << id
         << ch << " " << setw(15) << left << contact
         << ch << " " << setw(20) << left << reason_of_stay
         << ch << " " << setw(10) << left << room_no << ch << endl;
                for (int i = 0; i < capacity; i++)
                {
                    if (g_room[i].getRoomNo() == room_no)
                    {
                        g_room[i].allocateRoom(id);
                    }
                }
            }
            load_gst.close();
            for(int i=0; i<167; i++)
            cout<<ch;
            cout<<endl;
            cout << "guest data loaded successfully.\n";
        }
    }

    void update_data(string id, int new_room_no, bool leave_hostel)
{
    ifstream infile("save_guest_rooms.csv");
    ofstream temp_file("temp.csv");

    if (!infile.is_open() || !temp_file.is_open())
    {
        cout << "ERROR: Unable to open file to update the guest data." << endl;
        return;
    }

    string header;
    string name, guest_id, contact, reason_of_stay;
    int room_no;
    bool record_deleted = false;

    // Read the header line and write it to the temp file
    if (getline(infile, header))
    {
        temp_file << header << endl;
    }

    // Process each record line by line
    while (getline(infile, name, ','))
    {
        if (name.empty()) break; // Stop if there's an empty line
        getline(infile, guest_id, ',');
        getline(infile, contact, ',');
        getline(infile, reason_of_stay, ',');
        infile >> room_no;
        infile.ignore();

        // Check if this is the record to be updated or deleted
        if (guest_id == id)
        {
            if (leave_hostel)
            {
                record_deleted = true;
                continue; // Skip writing this record
            }
            room_no = new_room_no; // Update the room number
        }

        // Write data to the temp file
        temp_file << name << "," << guest_id << "," << contact << "," << reason_of_stay << "," << room_no << endl;
    }

    infile.close();
    temp_file.close();

    // Replace the old file with the updated file
    if (remove("save_guest_rooms.csv") != 0)
    {
        cout << "ERROR: Unable to delete the old file." << endl;
        return;
    }
    if (rename("temp.csv", "save_guest_rooms.csv") != 0)
    {
        cout << "ERROR: Unable to rename the temporary file." << endl;
        return;
    }

    cout << "Guest data updated successfully!" << endl;
}

    void add_guest()
    {
        cout << " \t\t\t\t\t\t\t\t  Guest details" << endl;
        for(int i=0; i<167; i++)
        cout<<ch;
        cout<<endl;
        cout << "Name : ";
        cin.ignore();
        getline(cin, name);
        cout << "ID : ";
        cin >> id;
        cout << "Contact : ";
        cin >> contact;
        cout << "Reason of stay : ";
        cin >> reason_of_stay;
        while(true)
        {
            cout<<"Room No (1-3) : ";
            cin>>room_no;
            if(room_no>3 || room_no<=0)
            {
                cout<<"You have entered an invalid room number. Try again. "<<endl;
            }
            else
            {
                break;
            }
        }
        // Search for an available room
        bool room_allocated = false;
        for (int i = 0; i < capacity; i++)
        {
            if(g_room[i].getRoomNo()==room_no)
            {
                if (g_room[i].isAvailable()==true)
                {
                    g_room[i].allocateRoom(id); // Assign the room to the student
                    room_allocated = true;
                    break;
                }
            }
        }

        if (room_allocated==true)
        {
            cout << "Room " << room_no << " allocated to " << name << endl;
            save_guest_room(name, id, contact, reason_of_stay, room_no);
        }
        else if(room_allocated==false)
        {
            cout << "Error :- No rooms available for allocation!" << endl;
        }
    }

    int change_room()
    {
        cout<<" \t\t\t\t\t\t\t\t  Change Room"<<endl;
        for(int i=0; i<167; i++)
        cout<<ch;
        cout<<endl;
        string ID;
        cout << "Enter your ID: ";
        cin >> ID;
        string choice;
        cout<<"Do you want to change the room?(yes/no) ";
        cin>>choice;
        if(choice=="no")
        {
            cout<<"------------Stay Happy----------"<<endl;
        }
        else if(choice=="yes")
        {
            int option;
            cout<<"what is the reason for changing the room? "<<endl;
            cout<<"1- Health problem "<<endl;
            cout<<"2- Room wiring problem "<<endl;
            cout<<"3- Air conditioning problems "<<endl;
            cin>>option;
            if(option==2)
            {
                cout<<"Sorry but we will fix this problem in 1-2 days."<<endl;
                cout<<"Don't take tension. Thank you. "<<endl;
            }

            else if(option==3)
            {
                cout<<"Sorry but we will fix this problem in a short time."<<endl;
                cout<<"Don't take tension. stay blessed. Thank you. "<<endl;
            }
            else if(option==1)
            {
                cout<<"wait a moment. I am working on it."<<endl;
                sleep(200000);
                bool room_found= false;
                int old_room_no = -1;
                // Find the student and free their current room
                int index;
                if(!room_found == true )
                {
                    for (int i = 0; i < capacity; i++)
                    {
                        if(g_room[i].getOccupantId()==ID)
                        {
                            index=i;
                            old_room_no = g_room[i].getRoomNo();
                            g_room[i].freeRoom(); // Free up the current room
                            room_found = true;
                            cout << "Room " << old_room_no << " freed. You can now change to another room." << endl;
                            break;
                        }
                    }
                }
                if (room_found==false)
                {
                    cout << "Faculty or staff person not found or room already freed." << endl;
                    return 1;
                }
                bool new_room_allocated;
                bool leave_hostel=false;

                for (int i = 0; i < capacity; i++)
                {
                    if(!(i==index))
                    {
                        if (g_room[i].isAvailable()==true)
                        {
                            g_room[i].allocateRoom(ID);
                            g_room[i].get_dues();
                            int new_room_no = g_room[i].getRoomNo();
                            cout << "Room " << new_room_no << " allocated to  " << ID << endl;
                            new_room_allocated = true;
                            leave_hostel=false;
                            update_data(g_room[i].getOccupantId() , new_room_no,false);
                            break;
                        }
                    }
                }
                if (new_room_allocated==false)
                {
                    cout << "No rooms available for the student!" << endl;
                }
            }
        }
    }

    int leave_hostel()
    {
        cout<<" \t\t\t\t\t\t\t\t  Leave Hostel"<<endl;
        for(int i=0; i<167; i++)
        cout<<ch;
        cout<<endl;
        string id;
        cout << "Enter your ID: ";
        cin >> id;
        bool room_found= false;
        bool leave_hostel=false;
        int old_room_no = -1;
        // Find the student and free their current room
        if(!room_found == true )
        {
            for (int i = 0; i < capacity; i++)
            {
                if(g_room[i].getOccupantId()==id)
                {
                    old_room_no = g_room[i].getRoomNo();
                    g_room[i].freeRoom(); // Free up the current room
                    room_found = true;
                    cout << "Room " << old_room_no << " freed successfully. "<<endl;
                    leave_hostel=true;
                    update_data(id, g_room[i].getRoomNo(),true);
                    break;
                }
            }
        }
        if (room_found==false)
        {
            cout << "FAculty/staff not found or room already freed." << endl;
            return 1;
        }
    }


    string type() const override
    {
        return "Guest";
    }

    void displayAvailableRooms()
    {
        cout<<" \t\t\t\t\t\t\t\t  Available Rooms"<<endl;
        for(int i=0; i<167; i++)
        cout<<ch;
        cout<<endl;
        bool any_room_available = false;
        for (int i = 0; i < capacity; ++i)
        {
            if (g_room[i].isAvailable())
            {
                g_room[i].displayRoom( type() );
                any_room_available = true;
            }
        }
        if (any_room_available==false)
        {
            cout << "No rooms are available." << endl;
        }
    }
};
int main()
{
    student_hostel stdt_hostel("0", "0", "0", "0", "0", "0");
    facultystaff_hostel fclty_hostel("0", "0", "0", "0", "0");
    guest_rooms gst_room("0", "0", "0", "0");
    stdt_hostel.load_student_hostel();
    fclty_hostel.load_Faculty_and_staff_hostel();
    gst_room.load_guest_room();
    system("CLS");
    int choice;

    do
    {
        for(int i=0; i<167; i++)
            cout<<ch;
        cout << "\n \t\t\t\t\t\t\t\t NAMAL UNIVERSITY Hostel " << endl;
        for(int i=0; i<167; i++)
            cout<<ch;
        cout << "\nEnter '1' for student" << endl;
        cout << "Enter '2' for Faculty/staff" << endl;
        cout << "Enter '3' for guest house" << endl;
        cout << "Enter '0' to exit from program" << endl;
        cout << "Enter choice: ";
        cin >> choice;
        system("CLS");
        switch (choice)
        {
        case 1:
        {
            int student_choice;
            do
            {
                for(int i=0; i<167; i++)
                    cout<<ch;
                cout << "\n \t\t\t\t\t\t\t\t Student Hostel " << endl;
                for(int i=0; i<167; i++)
                    cout<<ch;
                cout<<endl;
                cout << "\nEnter '1' to add a student" << endl;
                cout << "Enter '2' to change the room" << endl;
                cout<<  "Enter '3' to migrate" << endl;
                cout << "Enter '4' to display the list of students" << endl;
                cout << "Enter '5' to display available rooms" << endl;
                cout << "Enter '0' to return to the main menu" << endl;
                cout << "Enter choice: ";
                cin >> student_choice;
                switch (student_choice)
                {
                case 1:
                    system("CLS");
                    for(int i=0; i<167; i++)
                    cout<<ch;
                    cout<<endl;
                    stdt_hostel.addStudent();
                    break;
                case 2:
                    system("CLS");
                    for(int i=0; i<167; i++)
                    cout<<ch;
                    cout<<endl;
                    stdt_hostel.change_room();
                    break;

                case 3:
                    system("CLS");
                    for(int i=0; i<167; i++)
                    cout<<ch;
                    cout<<endl;
                    stdt_hostel.migration();
                    break;
                case 4:
                    system("CLS");
                    for(int i=0; i<167; i++)
                    cout<<ch;
                    cout<<endl;
                    stdt_hostel.load_student_hostel();
                    break;
                case 5:
                    system("CLS");
                    for(int i=0; i<167; i++)
                    cout<<ch;
                    cout<<endl;
                    stdt_hostel.displayAvailableRooms();

                    break;
                case 0:
                    cout << "Returning to main menu...\n";
                    break;
                default:
                    cout << "Invalid choice. Please try again." << endl;
                }
            }
            while (student_choice != 0);
            break;
        }
        case 2:
        {
            for(int i=0; i<167; i++)
            cout<<ch;
        cout << "\n \t\t\t\t\t\t\t\t NAMAL UNIVERSITY Hostel " << endl;
        for(int i=0; i<167; i++)
            cout<<ch;
            int faculty_choice;
            do
            {
                cout << "\nEnter '1' to add a Faculty or staff person" << endl;
                cout << "Enter '2' to change the room" << endl;
                cout<<  "Enter '3' to Leave Hostel" << endl;
                cout << "Enter '4' to display the list of Faculty and Staff members " << endl;
                cout << "Enter '5' to display available rooms " << endl;
                cout << "Enter '0' to return to the main menu" << endl;
                cout << "Enter choice: ";
                cin >> faculty_choice;
                switch (faculty_choice)
                {
                case 1:
                    system("CLS");
                    for(int i=0; i<167; i++)
                    cout<<ch;
                    cout<<endl;
                    fclty_hostel.add_faculty_or_staff();
                    break;
                case 2:
                    system("CLS");
                    for(int i=0; i<167; i++)
                    cout<<ch;
                    cout<<endl;
                    fclty_hostel.change_room();
                    break;
                case 3:
                    system("CLS");
                    for(int i=0; i<167; i++)
                    cout<<ch;
                    cout<<endl;
                    fclty_hostel.leave_hostel();
                    break;
                case 4:
                    system("CLS");
                    for(int i=0; i<167; i++)
                    cout<<ch;
                    cout<<endl;
                    fclty_hostel.load_Faculty_and_staff_hostel();
                    break;
                case 5:
                    system("CLS");
                    for(int i=0; i<167; i++)
                    cout<<ch;
                    cout<<endl;
                    fclty_hostel.displayAvailableRooms();
                    break;
                case 0:
                    cout << "Returning to main menu...\n";
                    break;
                default:
                    cout << "Invalid choice. Please try again." << endl;
                }
            }
            while (faculty_choice != 0);
            break;
        }
        case 3:
        {
            for(int i=0; i<167; i++)
            cout<<ch;
        cout << "\n \t\t\t\t\t\t\t\t NAMAL UNIVERSITY Hostel " << endl;
        for(int i=0; i<167; i++)
            cout<<ch;
            int guest_choice;
            do
            {
                cout << "\nEnter '1' to add a Guest" << endl;
                cout << "Enter '2' to change the room" << endl;
                cout<<  "Enter '3' to Leave Hostel" << endl;
                cout << "Enter '4' to display the list of Guests " << endl;
                cout << "Enter '5' to display available rooms " << endl;
                cout << "Enter '0' to return to the main menu" << endl;
                cout << "Enter choice: ";
                cin >> guest_choice;

                switch (guest_choice)
                {
                case 1:
                    system("CLS");
                    for(int i=0; i<167; i++)
                    cout<<ch;
                    cout<<endl;
                    gst_room.add_guest();
                    break;
                case 2:
                    system("CLS");
                    for(int i=0; i<167; i++)
                    cout<<ch;
                    cout<<endl;
                    gst_room.change_room();
                    break;
                case 3:
                    system("CLS");
                    for(int i=0; i<167; i++)
                    cout<<ch;
                    cout<<endl;
                    gst_room.leave_hostel();
                    break;
                case 4:
                    system("CLS");
                    for(int i=0; i<167; i++)
                    cout<<ch;
                    cout<<endl;
                    gst_room.load_guest_room();
                    break;
                case 5:
                    system("CLS");
                    for(int i=0; i<167; i++)
                    cout<<ch;
                    cout<<endl;
                    gst_room.displayAvailableRooms();
                    break;
                case 0:
                    cout << "Returning to main menu...\n";
                    break;
                default:
                    cout << "Invalid choice. Please try again." << endl;
                }
            }
            while (guest_choice != 0);
            break;
        }
        case 0:
        {
            cout << "-------------- Thank You for using our services --------------" << endl;
            break;
        }
        default:
            cout << "Invalid choice. Please try again." << endl;
        }
    }
    while (choice != 0);
    return 0;
}
